package env

import (
	"log"

	"github.com/joho/godotenv"
)

func LoadEnv(){
	if err := godotenv.Load(); err != nil {
		log.Fatal("Xatolik", err)
	}
}